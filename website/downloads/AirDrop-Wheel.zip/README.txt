==================================================
           AirDrop Wheel for macOS
==================================================

感謝下載 AirDrop Wheel！

【快速安裝】
1. 將「AirDrop Wheel.app」拖入「應用程式」（/Applications）目錄。
2. 首次啟動時，請依系統提示前往「系統設定」>「隱私權與安全性」：
   - 啟用「輔助使用」(Accessibility) 權限（用於全域拖曳與 ⌃ 快捷鍵偵測）。
   - 啟用「區域網絡」(Local Network) 權限（用於搜尋附近的 AirDrop 裝置）。
3. （選填）若需傳送桌面或下載項目等受保護檔案，建議由選單列圖示開啟「完全磁碟取用權限」。

【使用方式】
- 選取或拖曳檔案時，按住鍵盤上的 ⌃ Control 鍵，即可在游標位置彈出徑向輪盤。
- 將檔案甩入目標接收端扇區並放開滑鼠，即自動發送。

【接收端設定】
- 接收裝置（iPhone / iPad / Mac）之 AirDrop 需設定為「所有人（10 分鐘）」。

【開源專案與問題回報】
- 官方首頁：https://manfredsun.github.io/airdrop-wheel/
- GitHub 專案：https://github.com/Manfredsun/airdrop-wheel
- 問題回報：https://github.com/Manfredsun/airdrop-wheel/issues
- 授權條款：MIT License (c) 2026 Manfred Sun
